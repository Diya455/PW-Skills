/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./Distribution/pwhome.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}

